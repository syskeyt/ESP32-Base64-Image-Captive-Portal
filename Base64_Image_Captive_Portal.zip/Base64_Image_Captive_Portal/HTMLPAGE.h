const char HTMLPAGE[] PROGMEM = R"=====(
<div><img src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DHxgljNBAAO9TXL0Y4OHwAAAABJRU5ErkJggg==" alt="image" /> </div>
)=====";//file type here  ^^^                                                        // base64 code Here ^^^                                          //name here ^^^
